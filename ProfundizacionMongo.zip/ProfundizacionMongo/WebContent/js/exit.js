function exit(){
    $.getJSON("services/Login/Logout");
}